const Joi = require("joi");

const userRegValidationSchema = Joi.object({
  userId: Joi.string().email().required(),
  // ({ minDomainSegments: 3, tlds: { allow: ['com', 'net', 'ai'] } }),
  userName: Joi.string().min(3).max(30).required(),
  orgId: Joi.number().required(),
  password: Joi.string().min(6).required(),
});

module.exports = { userRegValidationSchema };
