const mongoose = require("mongoose");
const uniqueValidator = require("mongoose-unique-validator");

const userSchema = new mongoose.Schema({
  orgId: {
    type: Number,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    minLength: 10,
  },
  id: {
    type: Number,
    requried: true,
    unique: true,
  },
  name: {
    type: String,
    required: true,
    unique: true,
  },
  lastLogin: {
    type: Date,
  },
  password: {
    type: String,
    // required: true,
  },
  createdAt: {
    type: Date,
    required: true,
    default: () => Date.now(),
    immutable: true,
  },
  isDeleted: {
    type: Boolean,
    required: true,
    default: false,
  },
  accessToken: {
    type: String,
    // required: true,
  },
  kubotaAccessToken: {
    type: String,
    // required: true,
  },
  refreshToken: {
    type: String,
    // required: true,
  },
  validationCode: {
    type: String,
    // required: true,
  },
  lastUpdated: {
    type: Date,
    required: true,
    default: () => Date.now(),
  },
  isUserPresent: {
    type: Boolean,
    default: false,
  },
});

userSchema.plugin(uniqueValidator, { message: "is already taken." });
module.exports = mongoose.model("users", userSchema);
