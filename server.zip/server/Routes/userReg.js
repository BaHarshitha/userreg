const router = require("express").Router();
const userRegController = require("../Controllers/userReg.js");
//Registration For Organization
router.post("/orgs/user-registration", userRegController.userRegistration);

module.exports = router;
