const kubotaApiService = require("../services/KubotaService.js");
const User = require("../Models/user.js");
const md5 = require("md5");
const asyncHandler = require("express-async-handler");
const {
  userRegValidationSchema,
} = require("../Middleware/Validation/userRegValidationSchema.js");
const userRegistration = asyncHandler(async (req, res, next) => {
  const API_END_POINT = "user-registration";
  const registrationService = new kubotaApiService(API_END_POINT);

  try {
    // Validate the request body
    const validation = userRegValidationSchema.validate(req.body);
    if (validation.error) {
      return res
        .status(400)
        .json({ error: validation.error.message.replace(`\"`, "") });
    }

    // Extract user registration data from the request body
    const { userId, userName, orgId, password } = req.body;

    // Call the registration service to make the POST request to the external API
    const registeredUser = await registrationService.registerUser(
      req.body,
      API_END_POINT
    );
    // Log the successful registration
    if (registeredUser?.status === "approved") {
      // Check if a user with the same email already exists
      const existingUser = await User.findOne({ email: userId });
      if (existingUser) {
        return res.status(409).json({ error: "Email already exists" });
      }
      const existingUserName = await User.findOne({ name: userName });
      if (existingUserName) {
        return res.status(409).json({ error: "userName already exists" });
      }
      if (!existingUser && !existingUserName) {
        const userCount = await User.find().count();
        const registerUserValue = {
          id: userCount + 1,
          email: userId,
          name: userName,
          orgId: registeredUser.orgId,
          password: md5(password),
          // validationCode: registeredUser.validation_code_value,
          // kubotaAccessToken: registeredUser?.accessToken
        };

        await User.create(registerUserValue);
        res.status(200).json(registeredUser);
      }
    } else if (registeredUser?.status != "approved") {
      res
        .status(401)
        .json({ error: "Organization Didnot approved your userId " });
    }
    // Return the registered user data as a response
  } catch (error) {
    // Log the error
    console.error("User registration failed:", error);

    // Use a custom error handling middleware or respond with a standard error message
    res.status(500).json({ error: "User registration failed" });
  }
});

module.exports = { userRegistration };
