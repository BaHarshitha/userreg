const { mongoose } = require("mongoose");
const clc = require("cli-color");
const dotenv = require("dotenv");
const path = require("path");
const envPath = path.resolve(__dirname, ".env");
dotenv.config({ path: envPath });

const connectDB = () => {
  mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    serverSelectionTimeoutMS: 5000,
  });

  //   Listen for the 'connection' event
  mongoose.connection.on("connected", () => {
    const dbName = mongoose.connection.name;
    console.log(clc.green(`MongoDB connected to ${dbName}`));
  });

  // Listen for the 'error' event
  mongoose.connection.on("error", (err) => {
    console.error(clc.red("MongoDB connection error:", err));
  });
};

module.exports = connectDB;
