const express = require("express");
const dotenv = require("dotenv");
const path = require("path");
const envPath = path.resolve(__dirname, ".env");
dotenv.config({ path: envPath });
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");
const connectDB = require("./DB/db.js");
const initiateLogs = require("./Utils/logger.js");
const { networkInterfaces } = require("os");
const os = require("os");
const https = require("https");

const http = require("http");
const socketIO = require("socket.io");
const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: "*",
  },
});

app.use(cors());
// const clientFolder = require("")
app.set("views", path.resolve(__dirname, "views"));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true }));
app.use(bodyParser.json({ limit: "50mb" }));

// Swagger setup
const swaggerUI = require("swagger-ui-express");
const swaggerJSDoc = require("swagger-jsdoc");

const options = {
  definition: {
    openapi: "3.0.3",
    info: {
      title: "CLOUD APP",
      version: "1.0.0",
      description: "API documentation for CLOUD Application",
    },
    servers: [
      {
        url: `http://localhost:${process.env.PORT}`,
      },
    ],
  },
  apis: [
    "./Routes/user.js",
    "./Routes/job.js",
    "./Routes/task.js",
    "./Routes/taskType.js",
  ],
};

const specs = swaggerJSDoc(options);

const nets = networkInterfaces();
const ipAddrs = Object.create(null);
for (const name of Object.keys(nets)) {
  for (const net of nets[name]) {
    // Skip over non-IPv4 and internal (i.e. 127.0.0.1) addresses
    if (net.family === "IPv4" && !net.internal) {
      if (!ipAddrs[name]) ipAddrs[name] = [];
      ipAddrs[name].push(net.address);
    }
  }
}

app.use("/api-docs", swaggerUI.serve, swaggerUI.setup(specs));

// Initiate Mongodb connection
connectDB();

// socket connection

const socketDataMap = new Map();

io.on("connection", (socket) => {
  console.log("socket connected: " + socket.id);

  socket.on("modelPercentage", (data) => {
    console.log("Received data from client:", data);
    let clientInput = data.data;
    let username = data.username;
    socketDataMap.set(socket.id, { username, clientInput });
  });

  // Event handler when a socket disconnects
  socket.on("disconnect", () => {
    // Remove the mapping when the socket disconnects
    socketDataMap.delete(socket.id);
  });
});

//Redirect all url to client
app.use(express.static(path.join(process.env.CLIENT_FOLDER + "build")));

//Redirect the url to apk
app.use(
  "/apk",
  express.static(path.join(process.env.APK_FOLDER + "app-debug.apk"))
);

initiateLogs(app);

server.listen(process.env.PORT || 4000, () => {
  console.log("server addr:" + JSON.stringify(ipAddrs));
  console.log(`server is running in port ${process.env.PORT}`);
});

app.use(require("./Routes/userReg.js"));

// app.use(
//   "/media",
//   express.static("C:\\Users\\dimaag\\Resized_recentered_images\\aiData")
// );

const dirPath = path.join(__dirname, "../..");
// console.log("dirPath", dirPath);

app.use(
  "/media",
  express.static(`${dirPath}/Resized_recentered_images/aiData`)
);

app.get("*", (req, res, next) => {
  try {
    let redirectTo = path.join(
      __dirname,
      process.env.CLIENT_FOLDER + "build/index.html"
    );
    res.sendFile(redirectTo);
  } catch (error) {
    res.status(404).send("Error while redirecting");
  }
});

/// catch 404 and forward to error handler
app.use(function (req, res, next) {
  let err = new Error("Not Found");
  err.status = 404;
  next(err);
});

app.use(function (err, req, res, next) {
  res.status(err.status || 500);
  res.json({
    errors: {
      message: err.message,
      error: err.status,
    },
  });
});

module.exports = app;
